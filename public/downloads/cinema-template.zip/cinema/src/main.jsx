import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import CinemaSite from "./CinemaSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <CinemaSite />
  </StrictMode>
);
