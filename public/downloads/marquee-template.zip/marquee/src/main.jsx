import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import MarqueeSite from "./MarqueeSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <MarqueeSite />
  </StrictMode>
);
