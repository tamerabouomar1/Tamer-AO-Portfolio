import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import LumenSite from "./LumenSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <LumenSite />
  </StrictMode>
);
