import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import CloserSite from "./CloserSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <CloserSite />
  </StrictMode>
);
