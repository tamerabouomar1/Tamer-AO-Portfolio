import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import MentalitySite from "./MentalitySite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <MentalitySite />
  </StrictMode>
);
