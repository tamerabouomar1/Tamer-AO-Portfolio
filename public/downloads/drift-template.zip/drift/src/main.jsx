import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import DriftSite from "./DriftSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <DriftSite />
  </StrictMode>
);
