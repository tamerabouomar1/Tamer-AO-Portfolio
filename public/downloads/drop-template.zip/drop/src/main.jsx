import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import ToonhubSite from "./ToonhubSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ToonhubSite />
  </StrictMode>
);
