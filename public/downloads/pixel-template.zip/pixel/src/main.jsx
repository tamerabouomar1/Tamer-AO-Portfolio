import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import PixelSite from "./PixelSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <PixelSite />
  </StrictMode>
);
