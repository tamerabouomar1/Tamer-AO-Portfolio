import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import LedgerSite from "./LedgerSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <LedgerSite />
  </StrictMode>
);
