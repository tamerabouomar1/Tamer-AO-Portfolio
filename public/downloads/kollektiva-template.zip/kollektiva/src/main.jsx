import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import KollektivaSite from "./KollektivaSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <KollektivaSite />
  </StrictMode>
);
