import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import CharterSite from "./CharterSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <CharterSite />
  </StrictMode>
);
