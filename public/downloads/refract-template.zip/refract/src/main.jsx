import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import RefractSite from "./RefractSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <RefractSite />
  </StrictMode>
);
