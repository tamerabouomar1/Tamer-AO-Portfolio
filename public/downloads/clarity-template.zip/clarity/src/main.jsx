import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import ClaritySite from "./ClaritySite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ClaritySite />
  </StrictMode>
);
