import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import FrameSite from "./FrameSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <FrameSite />
  </StrictMode>
);
