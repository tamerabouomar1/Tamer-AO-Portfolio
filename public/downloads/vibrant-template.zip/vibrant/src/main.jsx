import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import VibrantSite from "./VibrantSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <VibrantSite />
  </StrictMode>
);
