import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import OrbitSite from "./OrbitSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <OrbitSite />
  </StrictMode>
);
