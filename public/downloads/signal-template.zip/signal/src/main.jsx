import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import SignalSite from "./SignalSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <SignalSite />
  </StrictMode>
);
