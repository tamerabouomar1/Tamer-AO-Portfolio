import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import BloomSite from "./BloomSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BloomSite />
  </StrictMode>
);
