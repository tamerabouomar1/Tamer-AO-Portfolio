import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import NoirSite from "./NoirSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <NoirSite />
  </StrictMode>
);
