import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import LaunchSite from "./LaunchSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <LaunchSite />
  </StrictMode>
);
