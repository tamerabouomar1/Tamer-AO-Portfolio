import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import EchoidSite from "./EchoidSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <EchoidSite />
  </StrictMode>
);
