import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import MatrixSite from "./MatrixSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <MatrixSite />
  </StrictMode>
);
