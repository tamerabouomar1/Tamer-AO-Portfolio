import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import StrataSite from "./StrataSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <StrataSite />
  </StrictMode>
);
