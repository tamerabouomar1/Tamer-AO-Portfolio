import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import ApertureSite from "./ApertureSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ApertureSite />
  </StrictMode>
);
