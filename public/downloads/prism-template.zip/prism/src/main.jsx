import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import PrismSite from "./PrismSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <PrismSite />
  </StrictMode>
);
