import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import AuroraSite from "./AuroraSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <AuroraSite />
  </StrictMode>
);
