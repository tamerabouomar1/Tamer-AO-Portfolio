import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import QuietSite from "./QuietSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <QuietSite />
  </StrictMode>
);
