import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import NebulaSite from "./NebulaSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <NebulaSite />
  </StrictMode>
);
