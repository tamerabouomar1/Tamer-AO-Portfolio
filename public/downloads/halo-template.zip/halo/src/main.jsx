import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import HaloSite from "./HaloSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <HaloSite />
  </StrictMode>
);
