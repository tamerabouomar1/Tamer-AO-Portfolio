import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import MuseSite from "./MuseSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <MuseSite />
  </StrictMode>
);
