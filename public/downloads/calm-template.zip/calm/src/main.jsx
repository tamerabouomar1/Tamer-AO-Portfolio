import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import CalmSite from "./CalmSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <CalmSite />
  </StrictMode>
);
