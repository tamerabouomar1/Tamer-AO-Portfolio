import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import LostSite from "./LostSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <LostSite />
  </StrictMode>
);
