import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import DarkroomSite from "./DarkroomSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <DarkroomSite />
  </StrictMode>
);
