import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import OddySite from "./OddySite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <OddySite />
  </StrictMode>
);
