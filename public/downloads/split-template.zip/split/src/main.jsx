import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import SplitSite from "./SplitSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <SplitSite />
  </StrictMode>
);
