import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import ReelSite from "./ReelSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ReelSite />
  </StrictMode>
);
