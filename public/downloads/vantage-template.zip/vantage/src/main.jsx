import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import VexSite from "./VexSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <VexSite />
  </StrictMode>
);
