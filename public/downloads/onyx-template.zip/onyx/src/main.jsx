import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import JackSite from "./JackSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <JackSite />
  </StrictMode>
);
