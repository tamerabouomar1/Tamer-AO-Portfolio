import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import PortalSite from "./PortalSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <PortalSite />
  </StrictMode>
);
