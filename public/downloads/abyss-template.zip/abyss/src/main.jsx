import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import AbyssSite from "./AbyssSite";
import "./reset.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <AbyssSite />
  </StrictMode>
);
